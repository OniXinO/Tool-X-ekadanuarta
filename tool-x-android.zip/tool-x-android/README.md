# Tool-X для Android (Termux)


## Передумови

1. Встановіть [Termux](https://f-droid.org/en/packages/com.termux/) з F-Droid
2. Надайте Termux дозвіл на доступ до сховища (якщо потрібно)

## Інсталяція

### Метод 1: Пряме завантаження і встановлення

1. Відкрийте Termux
2. Виконайте наступні команди:

```bash
# Встановлення curl
pkg install curl -y

# Завантаження і виконання інсталяційного скрипта
curl -O https://raw.githubusercontent.com/OniXinO/Tool-X-ekadanuarta/main/tool-x-android/install-termux.sh
chmod +x install-termux.sh
./install-termux.sh
```

### Метод 2: Клонування репозиторію

```bash
# Встановлення git
pkg install git -y

# Клонування репозиторію
git clone https://github.com/OniXinO/Tool-X-ekadanuarta

# Перехід у каталог і запуск інсталятора
cd Tool-X-ekadanuarta/tool-x-android
chmod +x install-termux.sh
./install-termux.sh
```

## Використання


## Налаштування зовнішнього вигляду Termux (опціонально)


```bash
pkg install wget -y
wget -O ~/.termux/font.ttf https://github.com/powerline/fonts/raw/master/DejaVuSansMono/DejaVu%20Sans%20Mono%20for%20Powerline.ttf
wget -O ~/.termux/colors.properties https://raw.githubusercontent.com/Mayccoll/Gogh/master/themes/Dracula.properties
termux-reload-settings
```

## Примітка

